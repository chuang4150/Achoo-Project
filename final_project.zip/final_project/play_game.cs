﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	class PlayCardDeck
	{
		 

		public static  void Main()
		{
			Random rand = new Random();//this creates a random to pull a random card out of the deck
			Console.WriteLine ("Welcome to Yaco's Casino! \nThis is a game of Blackjack. \n ");
			
			CardDeck Deck= new CardDeck();
			Deck.MainDeckAssemble ();

			while (Deck.CountDeck () != 0) {
				Console.WriteLine ("Number of Cards remaining in Deck: {0}", (Deck.CountDeck ()));
				Console.WriteLine ("Here are your cards: \n");
				Deck.PickUp (Deck.Deal (rand));
				Deck.PickUp (Deck.Deal (rand));
				Deck.PrintDeck ();
				Console.WriteLine ("Your current score is: {0}", Deck.HandValue ());

				bool b;
				do {
					Console.WriteLine ("Number of Cards remaining in Deck: {0}", (Deck.CountDeck ()));
					string response = PromptLine ("Hit or Stay? \n");
			
					if (response.Trim () == "Hit" || response.Trim () == "hit" || response.Trim()=="h" || response.Trim()=="H") {
						b = true;
						Deck.PickUp (Deck.Deal (rand));
						Console.WriteLine ("Here are your cards: ");
						Deck.PrintDeck ();
						Console.WriteLine ();
						Console.WriteLine ("Your current score is: {0}", Deck.HandValue ());
						if (Deck.HandValue () > 21) {
							Console.WriteLine ("BUST!\n");
							Deck.ClearHand ();
							b=false;
						}
						if (Deck.HandValue () == 21) {
							Console.WriteLine ("BlackJack!\n");
							Deck.ClearHand ();
							b=false;
						}
					} 
					if (response.Trim()=="Stay" || response.Trim()=="stay"){
						b = false;
					Deck.ClearHand();
					}
					else b = false;
				} while (b == true);
			}
		
		}

		public static void PrintHand(List <Card> hand) //Prints out every card currently in the deck
		{  
			for(int i = 0; i < hand.Count; i++){
				(hand [i]).PrintCard();
			
			}
		}
		/// After displaying the prompt, return a line from the keyboard.
		public static string PromptLine(string prompt)
		{
			Console.Write(prompt);
			return Console.ReadLine();
		}
	}

}

