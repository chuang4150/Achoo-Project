﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	class MainClass
	{
		/*public static void Main (string[] args)
		{
			Console.WriteLine ("Do you currently have a save file?");
			string name = UI.PromptLine ("If yes, enter name; if no, press enter.\nName: ");
			if (name != "") {
				int money = loadFile (name);
				Console.WriteLine ("Money = " + money);
			}
			saveFile (300);
			loadFile (UI.PromptLine ("enter what you just put"));
		}
		*/
		public static int loadFile (string name)
		{
			var fileReader = new StreamReader (name + ".txt");
			string moneyLine = fileReader.ReadLine();
			string moneyFinal = moneyLine.Substring (8);
			int returnMoney = int.Parse (moneyFinal);
			Console.WriteLine (returnMoney);
			fileReader.Close();
			return returnMoney;
		}
		public static void saveFile (int money)
		{
			string user = UI.PromptLine ("What is the name you would like to save as? ");
			user = user.Trim ();
			var fileWriter = new StreamWriter (user + ".txt");
			fileWriter.WriteLine ("Money: ${0}", money);
			fileWriter.Close ();
		}
	}
}
