﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	public class Card
	{
		private string Suite;
		private string Face;//the face value of the card (i.e., two, king, etc.)
		private int Points;//the points associated with a particular card (i.e., King = 10 points)


		public Card (string Face, string Suite, int Points)
		{
			this.Face = Face;
			this.Suite = Suite;
			this.Points = Points;
		}

		public int GetPoints()
		{
			return Points;
		}

		public string GetFace()
		{
			return Face;
		}

		public string GetSuite()
		{
			return Suite;
		}

		public void PrintCard()//prints out the card's face value and suite
		{
			Console.WriteLine ("{0} of {1}", Face, Suite);
		}




	}
}

