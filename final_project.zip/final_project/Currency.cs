﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	class Currency:YacoRoyale
	{
		private int bet; 




		public static void Money()
		{
			int money = 0;

			int level = UIF.PromptInt ("Choose the difficulty: Easy(1), Normal (2), Hard (3), Yacomode(4)");
			if(level==1){
				money==500;}
			if(level==2){
				money==300;}
			if(level==3){
				money==80;}
			if(level==4){
				money==50;}

			if (money = 1000){
				UIF.PromptInt ("You win! Would you like to continue? Yes(0) No(1)");


				public static int bet()
				{
					bet = UIF.PromptInt ("How much would you like to bet this round? (in increments of 10)");
					int money = money - bet;

					return "Your Bank:" + money;
				}
				public static void winner()
				{
					if (results = true)
						money = money + 2*bet;

				}
			}

			//You win if: player <= 21 && <dealer || dealer >21