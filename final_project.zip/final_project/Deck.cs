﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	public class CardDeck
	{
		private List <Card> MainDeck;//this will be the assembled standard deck of cards from which all cards are "dealt" to the player and the dealer
		private List <Card> HandDeck;//this will be the 'deck' of cards in the 'hand' of the player
		private List <Card> DealerDeck;//this will be the 'deck' of cards in the 'hand' of the dealer


		public CardDeck ()
		{
			MainDeck = new List <Card> ();
			HandDeck = new List <Card> ();
			DealerDeck = new List <Card> ();

		}


		public void MainDeckAssemble ()//creates a deck of cards with suite, value, and point parameters alterable by the programmer
		{
			string[] suites = { "Hearts", "Diamonds", "Spades", "Clubs" };
			string[] values = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" };
			int[] points = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11 };

			for (int i = 0; i < suites.Length; i++) {
				string suite = suites [i];
				for (int j = 0; j < values.Length; j++) {
					string value = values [j];
					int p = points [j];
					Card card = new Card (value, suite, p); 
					MainDeck.Add (card);
				}

			}

		}

		public void PickUp (Card card) //"picks up" a dealt card via adding its value to the Hand Deck
		{
			HandDeck.Add (card);
		}

		public int CountDeck ()//used to return the number of cards remaining in the main deck
		{
			return MainDeck.Count;
		}

		public void PrintDeck () //Prints out every card currently in the Hand deck
		{  
			for (int i = 0; i < HandDeck.Count; i++) {
				(HandDeck [i]).PrintCard ();
			}
			Console.WriteLine ();
		}

		public int HandValue()//returns the current value of all cards held in hand (ie the number of points the cards are worth summed up)
		{
			int score = 0;
			for (int i = 0; i < HandDeck.Count; i++) {
				score += (HandDeck [i]).GetPoints();
			}
			return score;
		}

		public void ClearHand() //empties the player's HandDeck after a hand is played
		{
			HandDeck.Clear ();
			DealerDeck.Clear ();
		}
		public Card Deal (Random rand)//"deals" a card from the main deck via returning its value
		{


			int j = rand.Next (MainDeck.Count - 1);
			Card hold = MainDeck [j];  
			MainDeck.Remove (MainDeck [j]);
			return hold;


		}
		public void DealerPickUp (Card card) //"picks up" a dealt card via adding its value to the Dealer Deck
		{
			DealerDeck.Add (card);
		}
		public int DealerValue()//returns the current value of all cards held in hand of dealer
		{
			int score = 0;
			for (int i = 0; i < DealerDeck.Count; i++) {
				score += (DealerDeck [i]).GetPoints();
			}
			return score;
		}


		public   void PrintHand() //Prints out the first card currently in the deck of the dealer
		{ 
			
			DealerDeck [0].PrintCard();

		}
	}
}
