﻿using System;

namespace BlackJack
{
	public class Players
	{
		public Players ()
		{
		}
	}
}

