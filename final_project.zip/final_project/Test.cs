﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	class TestCardDeck
	{
	public static  void Main()
	{
			CardDeck Deck= new CardDeck();
			List <Card> hand = new List <Card>(); 
			Deck.PrintDeck ();
			hand.Add(Deck.Deal ());
			Console.WriteLine ();
			Console.WriteLine ("Should Print all Heart cards except one");
			Deck.PrintDeck ();
			hand.Add(Deck.Deal ());
			Console.WriteLine ();
			Console.WriteLine ("Should Print all Heart cards except two");
			Deck.PrintDeck ();
			hand.Add(Deck.Deal ());
			Console.WriteLine ();
			Console.WriteLine ("Should Print all Heart cards except three");
			Deck.PrintDeck ();


	}
	}
}

