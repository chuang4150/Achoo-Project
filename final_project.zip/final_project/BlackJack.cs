﻿using System;
using System.IO;
using System.Collections.Generic;

namespace BlackJack
{
	class PlayCardDeck
	{

		public static  void Main()
		{
			int earnings=0; //The player's earnings
			Random rand = new Random();//this creates a random to pull a random card out of the deck
			Console.WriteLine ("Welcome to Yaco's Casino! \nThis is a game of BlackJack. \n ");

			string s= PromptLine("Do you know how to play BlackJack? (y/n) ");
			Console.WriteLine ();
			s.ToLower ();
			if (s.StartsWith ("n")) {
				var reader = new StreamReader ("../../YACOSINSTRUCTIONS.txt");
				while (!reader.EndOfStream){
					string currentLine = reader.ReadLine();
					Console.WriteLine(currentLine);
				}
				Console.WriteLine ();
				PromptLine ("Hit enter when you are done with the instructions.\n");
				prettyPrint();
				prettyPrint ();
			}

			else if(s.StartsWith("y")){
				Console.WriteLine("Ok, continue on to play the game\n");
			}
			Console.WriteLine ("Do you currently have a save file?");
			string name = PromptLine ("If yes, enter name; if no, press enter.\nName: ");
			prettyPrint ();
			if (name != "") {
				int money = loadFile (name);
				Console.WriteLine ("Money = " + money);
			}
			string level = PromptLine ("Choose the difficulty: Easy(1), Normal (2), Hard (3), Yacomode(4): ");
			int leveL = int.Parse (level);
			if(leveL==1){
				earnings=500;}
			if(leveL==2){
				earnings=300;}
			if(leveL==3){
				earnings=80;}
			if(leveL==4){
				earnings=50;}
			Console.WriteLine ("You chose level {0}; you start with ${1}.", level, earnings);
			prettyPrint ();

			CardDeck Deck= new CardDeck();
			Deck.MainDeckAssemble ();
			bool Again=true;
			int beT=0;
			while (Again == true) {
				
				Console.WriteLine ("Number of Cards remaining in Deck: {0}", (Deck.CountDeck ()));
				Console.WriteLine ("Here are your cards: \n");
				Deck.PickUp (Deck.Deal (rand));
				Deck.PickUp (Deck.Deal (rand));
				Deck.PrintDeck ();
				Console.WriteLine ("Your current score is: {0}", Deck.HandValue ());
				Deck.DealerPickUp (Deck.Deal (rand));
				Deck.DealerPickUp (Deck.Deal (rand));
				Console.WriteLine ("The dealer's first card is:");
				Deck.PrintHand ();
				Console.WriteLine ();


				Console.WriteLine ("Number of Cards remaining in Deck: {0}", (Deck.CountDeck ()));
				Console.WriteLine ("Your earnings: ${0}", earnings);

				string bet = PromptLine ("How much would you like to bet this round? (in increments of 10)");
				beT = int.Parse (bet);
				Again = false;

				string response = PromptLine ("Hit or Stay? \n");
				prettyPrint ();
				response = response.Trim ();
				response = response.ToLower ();
				while (response == "hit") {
					prettyPrint ();
					Deck.PickUp (Deck.Deal (rand));
					Console.WriteLine ("Here are your cards: ");
					Deck.PrintDeck ();
					Console.WriteLine ();
					Console.WriteLine ("Your current score is: {0}", Deck.HandValue ());
					if (Deck.HandValue () < 21) {
						response = (PromptLine ("Hit or Stay? \n"));
						response = response.Trim ();
						response = response.ToLower ();
					}
					if (Deck.HandValue () > 21) {
						Console.WriteLine ("Your score: {0}\n Dealer score: {1}", Deck.HandValue (), Deck.DealerValue ());
						Console.WriteLine ("BUST!\n The dealer wins this hand.");
						earnings -= beT;
						Deck.ClearHand ();
						response = "";
						prettyPrint ();
					}
					if (Deck.HandValue () == 21) {
						Console.WriteLine ("BlackJack!\n");
						prettyPrint ();
						Deck.ClearHand ();
						response = "";
						earnings += 2 * beT;


					} 
					 


				} 
				if (response == "stay") {
					prettyPrint ();
					int playerScore = Deck.HandValue ();
					Deck.ClearHand ();
					int dealerScore = Deck.DealerValue ();
					while (dealerScore < 15) {
						Deck.DealerPickUp (Deck.Deal (rand));
						dealerScore = Deck.DealerValue ();
						Deck.PrintHand ();
						if (dealerScore > 21) {
							Console.WriteLine ("The dealer busts.");
							Console.WriteLine ("You win!\n");
							prettyPrint ();
							Deck.ClearHand ();
							response = "";
							earnings = +2 * beT;

						}
					}
					Console.WriteLine ("Your score: {0}\n Dealer score: {1}", playerScore, dealerScore);


					if (dealerScore > playerScore && dealerScore < 21) {

						Console.WriteLine ("The Dealer wins!\n");
						earnings -= beT;
						prettyPrint ();
						Deck.ClearHand ();
						response = "";
					} else if (dealerScore < playerScore && playerScore < 21) {
						Console.WriteLine ("You win!\n");
						prettyPrint ();
						Deck.ClearHand ();
						response = "";
						earnings = +2 * beT;
					}

				}
				if (earnings == 0) {
					Console.WriteLine ("You lose.  Loser.  ");
					return;
				}
				if (earnings == 1000){
					Console.WriteLine ("You win!  Weiner!");
					return;
					}

				string answer = PromptLine ("Do you want to play another hand? (y/n)");
				if (answer == "y") {
					Again = true;
					if (Deck.CountDeck()<5){
						Deck.MainDeckAssemble ();
					}
				} else if (answer == "n") {
					Again = false;
					saveFile (earnings);
				}
			}




		}
		/// After displaying the prompt, return a line from the keyboard.
		public static string PromptLine(string prompt)
		{
			Console.Write(prompt);
			return Console.ReadLine();
		}
		public static int loadFile (string name)
		{
			string fileLocation = name + ".txt";
			while (!File.Exists(fileLocation)){
				string retry = PromptLine ("That name does not exist, enter another name or press enter to start.\nName: ");
				if (retry == "")
					return 500;
				fileLocation = retry + ".txt";
			}
			var fileReader = new StreamReader (fileLocation);
			string moneyLine = fileReader.ReadLine();
			string moneyFinal = moneyLine.Substring (8);
			int returnMoney = int.Parse (moneyFinal);
			Console.WriteLine (returnMoney);
			fileReader.Close();
			return returnMoney;
		}
		public static void saveFile (int money)
		{
			string user = PromptLine ("What is the name you would like to save as?\nName: ");
			user = user.Trim ();
			var fileWriter = new StreamWriter (user + ".txt");
			fileWriter.WriteLine ("Money: ${0}", money);
			fileWriter.Close ();
		}

		public static void prettyPrint()
		{
			for (int i = 0; i < 3; i++) {	
				Console.WriteLine ();
			}
		}
	}

}

